/* ===== FastCV Maker — script.js =====
   One shared `state` object feeds every template.
   TO ADD A TEMPLATE: push one entry into TEMPLATES: {id, name, render(d) => html}
   and add styles scoped to `.t-<id>` in style.css. Nothing else to change. */
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const KEY='fastcv.v1', A4W=794, A4H=1122;

/* ---------- Data ---------- */
const blank=()=>({fullName:'',jobTitle:'',email:'',phone:'',address:'',website:'',photo:'',summary:'',
  languages:'',certifications:'',projects:'',hobbies:'',achievements:'',courses:'',references:'',skills:[],
  experience:[{company:'',role:'',dates:'',desc:''}],education:[{school:'',degree:'',dates:'',desc:''}]});
const SAMPLE={fullName:'Alex Morgan',jobTitle:'Marketing Manager',email:'hello@example.com',phone:'+123-456-7890',
  address:'123 Anywhere St., Any City',website:'www.example.com',photo:'',
  summary:'Results-driven marketer with a strong record of growing brands and leading teams.',
  languages:'English\nSpanish',certifications:'',projects:'',hobbies:'',achievements:'',courses:'',references:'',skills:['Leadership','Digital Marketing','Negotiation','Creativity'],
  experience:[{company:'Aldenaire & Partners',role:'Marketing Manager',dates:'2022 - Present',desc:'Led campaigns across digital channels.'},
              {company:'Warner & Spencer',role:'Marketing Staff',dates:'2018 - 2022',desc:'Managed social media and events.'}],
  education:[{school:'Borcelle University',degree:'Master of Business',dates:'2012 - 2014',desc:''}]};
let state=blank(), tpl='navy';
try{const s=JSON.parse(localStorage.getItem(KEY)||'null');if(s){state={...blank(),...s.data};tpl=s.tpl||tpl;}}catch(e){}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify({data:state,tpl}));}catch(e){showMsg('Storage is full, so your photo was not saved. Try a smaller image.');}};

/* ---------- Template helpers ---------- */
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const nl=s=>esc(s).replace(/\n/g,'<br>');
const lines=s=>(s||'').split('\n').map(x=>x.trim()).filter(Boolean);
const ul=a=>a&&a.length?`<ul>${a.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'';
const sec=(t,h)=>h?`<section><h3>${t}</h3>${h}</section>`:'';
const txt=s=>s&&s.trim()?`<p>${nl(s)}</p>`:'';
const photo=d=>d.photo?`<img class="ph" src="${d.photo}" alt="">`:`<div class="ph">${esc((d.fullName||'?')[0].toUpperCase())}</div>`;
const contact=d=>[['✉',d.email],['☎',d.phone],['⌂',d.address],['◎',d.website]].filter(x=>x[1]).map(x=>`<div class="ct">${x[0]} ${esc(x[1])}</div>`).join('');
const exp=d=>d.experience.filter(e=>e.company||e.role).map(e=>`<div class="item"><div class="row"><b>${esc(e.role)}</b><span>${esc(e.dates)}</span></div><i>${esc(e.company)}</i>${txt(e.desc)}</div>`).join('');
const edu=d=>d.education.filter(e=>e.school||e.degree).map(e=>`<div class="item"><b>${esc(e.school)}</b><div>${esc(e.degree)}</div><small>${esc(e.dates)}</small>${txt(e.desc)}</div>`).join('');
const more=d=>sec('Achievements',ul(lines(d.achievements)))+sec('Courses',ul(lines(d.courses)))+sec('Projects',ul(lines(d.projects)))+sec('Certifications',ul(lines(d.certifications)))+sec('References',ul(lines(d.references)));
const extras=d=>more(d)+sec('Hobbies',ul(lines(d.hobbies)));
const first=n=>(n||'Your Name').trim().split(' ')[0], rest=n=>(n||'').trim().split(' ').slice(1).join(' ');

/* ---------- Templates (one function each, all read the same `d`) ---------- */
const TEMPLATES=[
 {id:'navy',name:'Navy Sidebar',render:d=>`
  <aside>${photo(d)}${sec('Contact',contact(d))}${sec('Education',edu(d))}${sec('Skills',ul(d.skills))}${sec('Language',ul(lines(d.languages)))}</aside>
  <div class="main"><h1>${esc(d.fullName||'Your Name')}</h1><h2>${esc(d.jobTitle)}</h2>
  ${sec('About me',txt(d.summary))}${sec('Experience',exp(d))}${extras(d)}</div>`},
 {id:'fire',name:'Orange Bold',render:d=>`
  <header>${photo(d)}<div class="ban"><h1>${esc(d.fullName||'Your Name')}</h1><h2>${esc(d.jobTitle)}</h2></div></header>
  <aside>${sec('Contact',contact(d))}${sec('Expertise',ul(d.skills))}${sec('Language',ul(lines(d.languages)))}${sec('Hobbies',ul(lines(d.hobbies)))}</aside>
  <div class="main">${sec('About Me',txt(d.summary))}${sec('Experience',exp(d))}${sec('Education',edu(d))}${more(d)}</div>`},
 {id:'clean',name:'Clean Grey',render:d=>`
  <div>${photo(d)}</div>
  <div class="head"><h1>${esc(first(d.fullName))}<b>${esc(rest(d.fullName))}</b></h1><h2>${esc(d.jobTitle)}</h2></div>
  <aside>${sec('Contact',contact(d))}${sec('Skills',ul(d.skills))}${sec('Language',ul(lines(d.languages)))}${sec('Hobbies',ul(lines(d.hobbies)))}</aside>
  <div class="main">${sec('About me',txt(d.summary))}${sec('Work experience',exp(d))}${sec('Education',edu(d))}${more(d)}</div>`}
];

/* ---------- Generic layouts: themed templates are just data (see T(...) below) ---------- */
const nameH=d=>`<h1>${esc(d.fullName||'Your Name')}</h1><h2>${esc(d.jobTitle)}</h2>`;
const LAYOUTS={
 side:(d,t)=>`<aside>${photo(d)}${sec('Contact',contact(d))}${t.eduSide?sec('Education',edu(d)):''}${sec('Skills',ul(d.skills))}${sec('Language',ul(lines(d.languages)))}${sec('Hobbies',ul(lines(d.hobbies)))}</aside><div class="main"><div class="nm">${nameH(d)}</div>${sec('About me',txt(d.summary))}${sec('Experience',exp(d))}${t.eduSide?'':sec('Education',edu(d))}${more(d)}</div>`,
 banner:d=>`<header>${photo(d)}<div class="nm">${nameH(d)}${txt(d.summary)}</div></header><div class="cols"><aside>${sec('Contact',contact(d))}${sec('Education',edu(d))}${sec('Skills',ul(d.skills))}${sec('Language',ul(lines(d.languages)))}</aside><div class="main">${sec('Experience',exp(d))}${more(d)}${sec('Hobbies',ul(lines(d.hobbies)))}</div></div>`,
 plain:d=>`<header><div class="nm"><h1>Curriculum Vitae</h1>${nameH(d)}</div>${photo(d)}</header>${sec('Personal data',contact(d))}${sec('Summary',txt(d.summary))}${sec('Education',edu(d))}${sec('Skills',ul(d.skills))}${sec('Language',ul(lines(d.languages)))}${sec('Experience',exp(d))}${more(d)}`
};
/* T(id, name, layout, headingStyle, cssVars, extra). Vars: a/at = sidebar bg/text, ac = accent, hc = heading text,
   bg/tx = page bg/text, ab/bt = banner bg/text, pr = photo radius, w = sidebar width */
const T=(id,name,layout,h,v,x={})=>TEMPLATES.push({id,name,layout,h,v,...x});
T('sun','Sunburst','side','bar',{a:'linear-gradient(#f9b812,#f59e0b)',at:'#111',ac:'#1d1d1b',hc:'#fff',bg:'#ebebeb',tx:'#222',pr:'0'},{eduSide:1});
T('classic','Classic CV','plain','line',{ac:'#000'});
T('blush','Blush Timeline','side','bar',{a:'#e8b9b9',at:'#3b3b3b',ac:'#3d3f3f',hc:'#fff',bg:'#ececec',tx:'#333',w:'300px'});
T('charcoal','Charcoal Pill','side','pill',{a:'#2b2c2e',at:'#fff',ac:'#2b2c2e',hc:'#fff',bg:'#fff',tx:'#222'},{eduSide:1});
T('midnight','Midnight','side','line',{a:'#00124a',at:'#fff',ac:'#00124a',hc:'#fff',bg:'#fff',tx:'#1b1b1b',pr:'50%'},{eduSide:1});
T('forest','Forest','side','line',{a:'#285a4a',at:'#fff',ac:'#285a4a',hc:'#fff',bg:'#f5f5f5',tx:'#111'});
T('ocean','Ocean','side','pill',{a:'#10234f',at:'#fff',ac:'#0b55a8',hc:'#fff',bg:'#fff',tx:'#1b2433'},{eduSide:1});
T('slate','Slate Rounded','side','bar',{a:'#000',at:'#fff',ac:'#526a83',hc:'#fff',bg:'#fff',tx:'#222',pr:'40px'},{eduSide:1});
T('crimson','Crimson','side','pill',{a:'linear-gradient(#6a0d16,#9a1722)',at:'#fff',ac:'#8b1220',hc:'#fff',bg:'#fff',tx:'#222'},{eduSide:1});
T('cyber','Cyber Blue','banner','line',{bg:'linear-gradient(#06204a,#1a56a8)',tx:'#fff',ac:'#0a84ff',ab:'transparent',bt:'#fff',pr:'0'});
T('sky','Sky Light','side','bar',{a:'#e5f0ff',at:'#1b2433',ac:'#0a63d8',hc:'#fff',bg:'#fff',tx:'#333'},{eduSide:1});
T('royal','Royal Wave','banner','line',{bg:'#fff',tx:'#111',ac:'#0a4fc4',ab:'linear-gradient(90deg,#052e7a,#0a4fc4)',bt:'#fff',pr:'16px'});
const renderCV=(id,d)=>{const t=TEMPLATES.find(t=>t.id===id);
  if(!t.layout)return `<div class="cv t-${id}">${t.render(d)}</div>`;
  const v=Object.entries(t.v).map(([k,x])=>`--${k}:${x}`).join(';');
  return `<div class="cv L-${t.layout} h-${t.h}" style="${v}">${LAYOUTS[t.layout](d,t)}</div>`;};

if(!TEMPLATES.find(t=>t.id===tpl))tpl='navy';
/* ---------- Gallery + template bar ---------- */
function buildPickers(){
  $('#gallery').innerHTML=TEMPLATES.map(t=>`<button class="card" data-t="${t.id}"><div class="mini">${renderCV(t.id,SAMPLE)}</div><span>${t.name}</span></button>`).join('');
  $('#tplBar').innerHTML=TEMPLATES.map(t=>`<button data-t="${t.id}">${t.name}</button>`).join('');
}
function pick(id,scroll){tpl=id;save();update();if(scroll)$('#builder').scrollIntoView();}
document.addEventListener('click',e=>{const b=e.target.closest('[data-t]');if(b)pick(b.dataset.t,!!b.closest('#gallery'));});

/* ---------- Live preview ---------- */
const isEmpty=()=>!['fullName','jobTitle','email','phone','address','website','summary'].some(k=>state[k].trim())&&!state.skills.length&&!state.experience.some(e=>e.company||e.role)&&!state.education.some(e=>e.school||e.degree);
function update(){
  $('#cv').innerHTML=renderCV(tpl,state);
  $('#empty').classList.toggle('hide',!isEmpty());
  $$('#tplBar button,.card').forEach(b=>b.classList.toggle('on',b.dataset.t===tpl));
  fit();
}
function fit(){const st=$('#stage'),k=Math.min(1,st.clientWidth/A4W);$('#scaler').style.transform=`scale(${k})`;st.style.height=A4H*k+'px';}
addEventListener('resize',fit);

/* ---------- Form binding ---------- */
function check(el){
  let m='';const v=el.value.trim();
  if(el.name==='fullName'&&!v)m='Enter your full name.';
  if(el.name==='email'&&!v)m='Enter your email so employers can reach you.';
  else if(el.name==='email'&&!/^\S+@\S+\.\S+$/.test(v))m='This email looks incomplete. Use the format name@site.com.';
  el.classList.toggle('bad',!!m);const s=el.parentElement.querySelector('.err');if(s)s.textContent=m;return !m;
}
$$('#form [name]').forEach(el=>{
  el.value=state[el.name]||'';
  el.addEventListener('input',()=>{state[el.name]=el.value;if(el.classList.contains('bad'))check(el);save();update();});
  el.addEventListener('blur',()=>{if(el.name==='fullName'||el.name==='email')check(el);});
});

/* Repeating entries (experience / education) */
const FIELDS={experience:[['role','Job title'],['company','Company'],['dates','Dates (e.g. 2020 - Present)']],education:[['degree','Degree'],['school','School'],['dates','Dates']]};
function renderList(k){
  const box=$(k==='experience'?'#expList':'#eduList');
  box.innerHTML=state[k].map((e,i)=>`<div class="entry">${FIELDS[k].map(([f,l])=>`<label>${l}<input data-l="${k}" data-i="${i}" data-f="${f}" value="${esc(e[f])}"></label>`).join('')}
    <label>Description<textarea rows="2" data-l="${k}" data-i="${i}" data-f="desc">${esc(e.desc)}</textarea></label>
    ${state[k].length>1?`<button type="button" class="rm" data-rm="${k}" data-i="${i}">Remove</button>`:''}</div>`).join('');
}
document.addEventListener('input',e=>{const t=e.target;if(t.dataset.l){state[t.dataset.l][t.dataset.i][t.dataset.f]=t.value;save();update();}});
document.addEventListener('click',e=>{
  const a=e.target.dataset.add,r=e.target.dataset.rm;
  if(a){state[a].push(a==='experience'?{company:'',role:'',dates:'',desc:''}:{school:'',degree:'',dates:'',desc:''});renderList(a);save();update();}
  if(r){state[r].splice(e.target.dataset.i,1);renderList(r);save();update();}
});

/* Skills as tags */
function renderTags(){
  $$('#tags .tag').forEach(n=>n.remove());
  $('#tagIn').before(...state.skills.map((s,i)=>{const n=document.createElement('span');n.className='tag';n.innerHTML=`${esc(s)}<button type="button" aria-label="Remove ${esc(s)}" data-sk="${i}">×</button>`;return n;}));
}
$('#tagIn').addEventListener('keydown',e=>{
  if(e.key==='Enter'||e.key===','){e.preventDefault();const v=e.target.value.trim();
    if(v&&!state.skills.includes(v)){state.skills.push(v);renderTags();save();update();}e.target.value='';}
});
$('#tags').addEventListener('click',e=>{if(e.target.dataset.sk!==undefined){state.skills.splice(e.target.dataset.sk,1);renderTags();save();update();}});

/* Photo upload (downscaled so localStorage stays small) */
$('#photoIn').addEventListener('change',e=>{
  const f=e.target.files[0];if(!f)return;const img=new Image();
  img.onload=()=>{const k=Math.min(1,500/Math.max(img.width,img.height)),c=document.createElement('canvas');
    c.width=img.width*k;c.height=img.height*k;c.getContext('2d').drawImage(img,0,0,c.width,c.height);
    state.photo=c.toDataURL('image/jpeg',.85);$('#photoDel').hidden=false;save();update();};
  img.onerror=()=>showMsg('That file could not be read as an image. Try a JPG or PNG.');
  img.src=URL.createObjectURL(f);
});
$('#photoDel').addEventListener('click',e=>{state.photo='';$('#photoIn').value='';e.target.hidden=true;save();update();});

/* ---------- Export ---------- */
function showMsg(t){$('#msg').textContent=t;}
function validate(){
  showMsg('');const ok=['fullName','email'].map(n=>check($(`[name=${n}]`))).every(Boolean);
  if(!ok){showMsg('Fill in the highlighted fields before exporting.');$('#form').scrollIntoView();}return ok;
}
$('#pdfBtn').addEventListener('click',()=>{
  if(!validate())return;
  const node=$('#cv .cv').cloneNode(true);node.style.cssText='position:fixed;left:-9999px;top:0';document.body.appendChild(node);
  html2pdf().set({margin:0,filename:`${state.fullName.trim().replace(/\s+/g,'_')}_CV.pdf`,image:{type:'jpeg',quality:.98},
    html2canvas:{scale:2,useCORS:true,scrollX:0,scrollY:0},jsPDF:{unit:'mm',format:'a4',orientation:'portrait'}})
    .from(node).save().catch(()=>showMsg('PDF export failed. Use Print and choose Save as PDF.')).finally(()=>node.remove());
});
$('#printBtn').addEventListener('click',()=>{if(validate())print();});
$('#resetBtn').addEventListener('click',()=>{
  if(!confirm('Clear everything you entered?'))return;
  state=blank();save();location.reload();
});

/* ---------- Init ---------- */
buildPickers();renderList('experience');renderList('education');renderTags();$('#photoDel').hidden=!state.photo;update();
